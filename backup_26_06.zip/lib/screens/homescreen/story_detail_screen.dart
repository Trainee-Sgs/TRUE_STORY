import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'story_reader_screen.dart';
import '../../widgets/comment_bottom_sheet.dart';
import '../../widgets/language_dialog.dart';
import '../../utils/share_helper.dart';
import '../../widgets/save_button.dart';
import '../../widgets/like_button.dart';
import '../OnboardingScreen/author_profile_screen.dart';
import '../../widgets/story_options_sheet.dart';

import '../../utils/history_manager.dart';

class StoryDetailScreen extends StatefulWidget {
  final Map<String, dynamic> storyData;

  const StoryDetailScreen({super.key, required this.storyData});

  @override
  State<StoryDetailScreen> createState() => _StoryDetailScreenState();
}

class _StoryDetailScreenState extends State<StoryDetailScreen> {
  @override
  void initState() {
    super.initState();
    // Add to history when viewed
    WidgetsBinding.instance.addPostFrameCallback((_) {
      HistoryManager().addToHistory(widget.storyData);
    });
  }

  @override
  Widget build(BuildContext context) {
    final storyData = widget.storyData;
    final double w = MediaQuery.of(context).size.width;
    final double scale = (w / 360).clamp(0.8, 1.4);
    final bool isLocalFile = storyData['isLocalFile'] ?? false;
    final String imagePath = storyData['image'] ?? 'assets/images/sundar.png';

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Top Image Section ────────────────────────────────────────
            Stack(
              children: [
                isLocalFile 
                  ? Image.file(
                      File(imagePath),
                      width: double.infinity,
                      height: 380 * scale,
                      fit: BoxFit.cover,
                    )
                  : Image.asset(
                      imagePath,
                      width: double.infinity,
                      height: 380 * scale,
                      fit: BoxFit.cover,
                    ),
                // Gradient Overlay
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withValues(alpha: 0.4),
                          Colors.transparent,
                          Colors.black.withValues(alpha: 0.6),
                        ],
                      ),
                    ),
                  ),
                ),
                // Heading Text "SUNDAR"
                Positioned(
                  top: 40 * scale,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Text(
                      storyData['bannerTitle'] ?? 'SUNDAR',
                      style: GoogleFonts.cinzel(
                        fontSize: 32 * scale,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xFFC7E9E7),
                        letterSpacing: 4,
                      ),
                    ),
                  ),
                ),
                // Bottom Text "GOOGLE TO CEO"
                Positioned(
                  bottom: 20 * scale,
                  left: 0,
                  right: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildBannerFooterItem('GOOGLE', '2015', scale),
                      _buildBannerFooterItem('TO', 'TO', scale),
                      _buildBannerFooterItem('CEO', '2024', scale),
                    ],
                  ),
                ),
                // Back Button
                Positioned(
                  top: 40 * scale,
                  left: 10 * scale,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                // Top Right Icons
                Positioned(
                  top: 40 * scale,
                  right: 10 * scale,
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Color(0xFFFFD700),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.workspace_premium, size: 18 * scale, color: Colors.white),
                      ),
                      IconButton(
                        icon: const Icon(Icons.more_vert, color: Colors.white),
                        onPressed: () => showStoryOptions(context, storyData['title'] ?? '', storyData),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            // ── InteractionBar ───────────────────────────────────────────
            Padding(
              padding: EdgeInsets.fromLTRB(16 * scale, 12 * scale, 16 * scale, 8 * scale),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => LanguageDialog.show(context, scale),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: const BoxDecoration(
                        color: Color(0xFF7C348D),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.translate, size: 16 * scale, color: Colors.white),
                    ),
                  ),
                  SizedBox(width: 8 * scale),
                  Icon(Icons.star, color: Colors.amber, size: 18 * scale),
                  SizedBox(width: 2 * scale),
                  Text(
                    '4.6(50K)',
                    style: GoogleFonts.poppins(fontSize: 12 * scale, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(width: 12 * scale),
                  Icon(Icons.menu_book, color: Colors.grey, size: 18 * scale),
                  SizedBox(width: 4 * scale),
                  Text(
                    '1M',
                    style: GoogleFonts.poppins(fontSize: 12 * scale, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => CommentBottomSheet.show(context, scale),
                    child: _buildActionButton(Icons.comment_outlined, 'Comment', scale),
                  ),
                  GestureDetector(
                    onTap: () => ShareHelper.shareStory(
                      storyData['title'] ?? 'Wonderful Story',
                      storyData['overview'] ?? 'Read this inspiring story on True Story.',
                    ),
                    child: _buildActionButton(Icons.share_outlined, 'Share', scale),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 6 * scale),
                    child: SaveButton(
                      id: storyData['title'] ?? 'unknown',
                      scale: scale,
                      storyData: storyData,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 6 * scale),
                    child: LikeButton(
                      id: storyData['title'] ?? 'unknown',
                      scale: scale,
                    ),
                  ),
                ],
              ),
            ),

            // ── Author Section ───────────────────────────────────────────
            Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 8 * scale),
                child: RichText(
                  text: TextSpan(
                    style: GoogleFonts.poppins(color: Colors.black54, fontSize: 13 * scale),
                    children: [
                      const TextSpan(text: 'Posted by : '),
                      WidgetSpan(
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const AuthorProfileScreen(authorName: 'Tamilarasi'),
                              ),
                            );
                          },
                          child: Text(
                            'Tamilarasi',
                            style: GoogleFonts.poppins(
                              color: const Color(0xFF008080),
                              decoration: TextDecoration.underline,
                              fontSize: 13 * scale,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // ── Content Section ──────────────────────────────────────────
            Center(
              child: Text(
                storyData['title']?.toUpperCase() ?? 'SUNDAR PICHAI',
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(
                  fontSize: 18 * scale,
                  fontWeight: FontWeight.w800,
                  color: Colors.black,
                ),
              ),
            ),
            SizedBox(height: 12 * scale),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 24 * scale),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Story Overview :',
                    style: GoogleFonts.poppins(
                      fontSize: 15 * scale,
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  SizedBox(height: 10 * scale),
                  Text(
                    storyData['overview'] ?? 
                    'Sundar Pichai’s life is an inspiring journey from humble beginnings to leading one of the world’s top technology companies, Google. Born into a middle-class family in India, he shaped his path through education, hard work, and innovation. After joining Google, his contributions to key products like Chrome, Android, and Google Drive transformed the way billions of people use technology. Appointed as Google’s CEO in 2019, he is known for his calm leadership, user-focused thinking, and long-term vision. His story reflects perseverance, simplicity, and values-driven succe.. ',
                    style: GoogleFonts.poppins(
                      fontSize: 13 * scale,
                      color: Colors.black.withValues(alpha: 0.85),
                      height: 1.6,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => StoryReaderScreen(storyData: storyData),
                        ),
                      );
                    },
                    child: Text(
                      'READ MORE',
                      style: GoogleFonts.poppins(
                        color: const Color(0xFF00CED1),
                        fontWeight: FontWeight.bold,
                        fontSize: 13 * scale,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── Bottom Button ────────────────────────────────────────────
            Padding(
              padding: EdgeInsets.all(24 * scale),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StoryReaderScreen(storyData: storyData),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7C348D),
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10 * scale),
                  ),
                ),
                child: Text(
                  'READ NOW',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 18 * scale,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBannerFooterItem(String top, String bottom, double scale) {
    return Column(
      children: [
        Text(
          top,
          style: GoogleFonts.poppins(
            color: Colors.white.withValues(alpha: 0.8),
            fontSize: 10 * scale,
            fontWeight: FontWeight.w500,
          ),
        ),
        Text(
          bottom,
          style: GoogleFonts.poppins(
            color: Colors.white.withValues(alpha: 0.6),
            fontSize: 8 * scale,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(IconData icon, String label, double scale, {Color? color}) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 6 * scale),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 20 * scale, color: color ?? Colors.black54),
          SizedBox(height: 2 * scale),
          Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 10 * scale,
              color: color ?? Colors.grey.shade600,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
